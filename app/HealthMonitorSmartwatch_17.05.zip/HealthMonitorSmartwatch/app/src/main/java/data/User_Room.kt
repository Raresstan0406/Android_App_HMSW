package data

data class Room(
    val name: String = "",
)
