package data

data class TempPulseSpO2Result(
    val message:String,
    val connectionState: ConnectionState
)
