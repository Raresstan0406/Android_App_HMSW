package eu.test.healthmonitorsmartwatch

import androidx.annotation.DrawableRes

sealed class DrScreen(val title: String, val route:String) {

    sealed class DrawerScreen(val dTitle: String, val dRoute: String, @DrawableRes val icon: Int)
        : DrScreen(dTitle, dRoute){
            object Home: DrawerScreen(
                "Home",
                "home",
                R.drawable.baseline_home_24
            )
             object Account: DrawerScreen(
                 "Account",
                 "account",
                 R.drawable.baseline_person_pin_24
             )
            object HealthValues: DrawerScreen(
                "Health Values",
                "healt values",
                R.drawable.baseline_health_and_safety_24
            )
            object Search: DrawerScreen(
                "Search",
                "search",
                R.drawable.baseline_person_add_24
            )
            object ChatRooms: DrawerScreen(
                "Chatrooms",
                "chatrooms",
                R.drawable.baseline_chat_24
            )
            /*object Bluetooth: DrawerScreen(
                "Bluetooth",
                "bluetooth",
                R.drawable.baseline_bluetooth_24
            )
            object BluetoothLE: DrawerScreen(
                "BluetoothLE",
                "bluetoothLE",
                R.drawable.baseline_bluetooth_24
            )*/
        }
}

    val screensInDrawer = listOf(
        DrScreen.DrawerScreen.Home,
        DrScreen.DrawerScreen.Account,
        DrScreen.DrawerScreen.HealthValues,
        DrScreen.DrawerScreen.Search,
        DrScreen.DrawerScreen.ChatRooms,
        //DrScreen.DrawerScreen.Bluetooth,
        //DrScreen.DrawerScreen.BluetoothLE
    )