package eu.test.healthmonitorsmartwatch

import android.app.Application



/*class userHmswAPP : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.provide(this)
    }
}*/