package eu.test.healthmonitorsmartwatch

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.test.healthmonitorsmartwatch.ui.theme.AuthViewModel

@Composable
fun AccountScreenHMSW(authViewModel: AuthViewModel){
    Column(modifier = Modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(colors = listOf(Color.Blue, Color.Green)))) {
        Text(authViewModel.currentUserEmail.value, fontSize = 24.sp, color = Color.White)
        Text(authViewModel.currentUserFirstName.value, fontSize = 24.sp, color = Color.White)
        Text(authViewModel.currentUserLastName.value, fontSize = 24.sp, color = Color.White)
        Text(authViewModel.currentUserAge.value, fontSize = 24.sp, color = Color.White)
        Text(authViewModel.currentUserDeviceType.value, fontSize = 24.sp, color = Color.White)
        Text(authViewModel.currentUserAccountType.value, fontSize = 24.sp, color = Color.White)
    }
}